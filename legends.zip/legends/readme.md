# Legends-Minecraft-mod 
This mod must be purchased and cannot be downloaded here. Please visit https://cllays.wixsite.com/legends-minecraft-mo to buy it. Thank you
